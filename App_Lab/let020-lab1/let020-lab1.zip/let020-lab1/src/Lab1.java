import java.util.Arrays;
public class Lab1{

	public static void main (String[] args)
	{
		GradeCalculator studentA = new GradeCalculator();
		final int size = 10;
		double [] quizArray = new double[size];
		double [] assignmentArray = new double[size];
		
		quizArray[0] = 90;
		quizArray[1] = 100;
		quizArray[2] = 78;
		quizArray[3] = 86;
		quizArray[4] = 54;
		quizArray[5] = 98;
		quizArray[6] = 90;
		quizArray[7] = 60;
		quizArray[8] = 80;
		quizArray[9] = 88;
		
		assignmentArray[0] = 90;
		assignmentArray[1] = 96;
		assignmentArray[2] = 95;
		assignmentArray[3] = 85;
		assignmentArray[4] = 100;
		assignmentArray[5] = 53;
		assignmentArray[6] = 99;
		assignmentArray[7] = 94;
		assignmentArray[8] = 88;
		assignmentArray[9] = 86;
//		
//		Arrays.fill(quizArray,80.0 );
//		Arrays.fill(assignmentArray, 80.0);
		
		studentA.setFinal(90.0);
		studentA.setMidterm(80.0);
		studentA.setProject(97.0);
		studentA.setquiz(quizArray);
		studentA.setassignment(assignmentArray);
		
		System.out.println(studentA);
		

	}
}