package application.model;

import javafx.scene.paint.Color;

public class Board {
	
	private Square[][] squares;
	
	public Board() {
		this.squares = new Square[2][4];
		
		squares[0][0] = new Square(Color.RED);
		squares[0][1] = new Square(Color.BLUE);
		squares[0][2] = new Square(Color.GREEN);
		squares[0][3] = new Square(Color.YELLOW);
		squares[1][0] = new Square(Color.GREEN);
		squares[1][1] = new Square(Color.RED);
		squares[1][2] = new Square(Color.YELLOW);
		squares[1][3] = new Square(Color.BLUE);
	}
	
	public void hide( int x, int y ) {
		// TODO: Hide the given square
		//		 Hint: call the corresponding method in the Square class to help you hide it.
	}
	
	public void hideBoth() {
		// TODO: Hide both squares - the user's 1st & 2nd choices this round
		//      Hint: this should be called if no match is found
		//		Hint 2: this method should call a hide method twice, one for each square.
	}
	
	public boolean matchFound() {
		// TODO: Check to see if a match is found, and return true if so
		return false;
	}
	
	public String reveal( String buttonName ) {
		
		int x = buttonName.startsWith("zero") ? 0 : 1;
		int y;
		
		if( buttonName.endsWith("zero") )
			y = 0;
		else if( buttonName.endsWith("one") )
			y = 1;
		else if( buttonName.endsWith("two") )
			y = 2;
		else 
			y = 3;
		
		return this.reveal(x,y);
	}	
		
	public String reveal( int x, int y ) {
		squares[x][y].reveal();
		return squares[x][y].getColorAsCode();
	}
	
	/**
	 * ToString method returns a String representation of the current state of the game board.
	 * 
	 * @return String Board colors currently revealed.
	 */
	public String toString() {
		String ret = squares[0][0] + ", " + squares[0][1] + ", ";
		ret += squares[0][2] + ", " + squares[0][3] + "\n";
		ret += squares[1][0] + ", " + squares[1][1] + ", "; 
		ret += squares[1][2] + ", " + squares[1][3];	
		return ret;
	}
}