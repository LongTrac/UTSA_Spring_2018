package application.controller;

import application.model.Board;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MainController implements EventHandler<ActionEvent>{

	@FXML
	Button zero0, zero1, zero2, zero3, one0, one1, one2, one3;
	
	private Board gameBoard = new Board();
	

	@Override
	public void handle(ActionEvent event) {
		Button selected = (Button) event.getSource();
		System.out.println("User selected square: " + selected.toString());
		
		String color = gameBoard.reveal(selected.getId());
		if( color!=null )
			selected.setStyle("-fx-background-color: #" + color );
		
		System.out.println( gameBoard );
	}
}